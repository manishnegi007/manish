package com.example.service.Impl;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.dto.LoginDTO;
import com.example.service.LoginService;
import com.example.utils.Commons;
import com.example.utils.XTrustProviderSSL;

@Service
public class LoginServiceImpl implements LoginService{

	Logger log =Logger.getLogger(LoginServiceImpl.class);
	
	@Value("${spring.enable.proxy.development}")
	private String devMode;
	
	@Value("${com.qc.admapp.loginURL}")
	private String soaLoginURL;

	@Value("${com.qc.admapp.userDetailUrl}")
	private String userDetailsURL;
	
	@Override
	public Boolean login(LoginDTO loginDTO,HttpServletRequest request) {
		Boolean result=false;
		XTrustProviderSSL.trustHttps();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("X-IBM-Client-Id", "01004e2d-6d79-4539-883a-294c5663c5bd");
		headers.set("X-IBM-Client-Secret", "C2rI6cG7kT4cF5oF0aC6qI7cB3dD1yJ7tL7sR3lC5mX8pO4yG7");
		StringBuilder sb=new StringBuilder();
		
		sb.append(" 	{	 ");
		sb.append(" 	  \"request\": {	 ");
		sb.append(" 	    \"header\": {	 ");
		sb.append(" 	      \"soaCorrelationId\": \"2569887\",");
		sb.append(" 	      \"soaMsgVersion\": \"1.0\",	 ");
		sb.append(" 	      \"soaAppId\": \"ADM\",");
		sb.append(" 	      \"soaUserId\": \"ADM123\",");
		sb.append(" 	      \"soaPassword\": \"cHdkNHJBRE0=\"");
		sb.append(" 	    },	 ");
		sb.append(" 	    \"requestData\": {	 ");
		sb.append(" 	      \"requestPayload\": {	 ");
		sb.append(" 	        \"transactions\": [{	 ");
		sb.append(" 	           \"ssoPassword\": \"").append(loginDTO.getPassword()).append("\",");
		sb.append(" 	          \"ssoId\": \"").append(loginDTO.getUsername()).append("\"");
		sb.append(" 	        }]	 ");
		sb.append(" 	      }	 ");
		sb.append(" 	    }	 ");
		sb.append(" 	  }	 ");
		sb.append(" 	}	 ");

	    log.info("Request Body LOGIN"+sb.toString());
		HttpEntity<String> entity=new HttpEntity<String>(sb.toString(),	headers);
		RestTemplate restTemplate=new RestTemplate();
		
		if(devMode.equalsIgnoreCase("Y")){
			    SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			    Proxy proxy= new Proxy(Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
			    requestFactory.setProxy(proxy);
			    restTemplate.setRequestFactory(requestFactory);
		}
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		ResponseEntity<String> response = restTemplate.exchange(soaLoginURL, HttpMethod.POST, entity,String.class);
		if(response.getStatusCodeValue() == 200){
		  Map loginResponse = new  Commons().getGsonData(response.getBody());
		  Map responseData = (Map)((Map)loginResponse.get("response")).get("responseData");
		  List<Map<String,String>> transactions =(List<Map<String,String>>)responseData.get("Transactions");
			if(transactions!=null && !transactions.isEmpty()){
				if(transactions.get(0).get("status").equalsIgnoreCase("success")){
					result = getUserDetails(loginDTO,request);
				}else{
					log.error("Error While login through SOA API");
				}
			}else{
				log.error("Error While login through SOA API");
			}
        }else{
        	log.error("Error While login through SOA API");
        }
       return result;		
	}

	private Boolean getUserDetails(LoginDTO loginDTO,HttpServletRequest request) {
		// TODO Auto-generated method stub
		Boolean result =false;
		XTrustProviderSSL.trustHttps();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("X-IBM-Client-Id", "01004e2d-6d79-4539-883a-294c5663c5bd");
		headers.set("X-IBM-Client-Secret", "C2rI6cG7kT4cF5oF0aC6qI7cB3dD1yJ7tL7sR3lC5mX8pO4yG7");
		StringBuilder sb=new StringBuilder();
		
		sb.append(" 	{	 ");
		sb.append(" 	  \"request\": {	 ");
		sb.append(" 	    \"header\": {	 ");
		sb.append(" 	      \"soaCorrelationId\": \"123464\",");
		sb.append(" 	      \"soaMsgVersion\": \"1.0\",	 ");
		sb.append(" 	      \"soaAppId\": \"ADM\",");
		sb.append(" 	      \"soaUserId\": \"ADM123\",");
		sb.append(" 	      \"soaPassword\": \"cHdkNHJBRE0=\"");
		sb.append(" 	    },	 ");
		sb.append(" 	    \"requestData\": {	 ");
		sb.append(" 	      \"requestPayload\": {	 ");
		sb.append(" 	        \"transactions\": [{	 ");
		sb.append(" 	          \"ssoId\": \"").append(loginDTO.getUsername()).append("\"");
		sb.append(" 	        }]	 ");
		sb.append(" 	      }	 ");
		sb.append(" 	    }	 ");
		sb.append(" 	  }	 ");
		sb.append(" 	}	 ");

	    log.info("Request Body USERDETAILS "+sb.toString());
	    
		HttpEntity<String> entity=new HttpEntity<String>(sb.toString(),	headers);
		RestTemplate restTemplate=new RestTemplate();
		
		if(devMode.equalsIgnoreCase("Y")){
			    SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			    Proxy proxy= new Proxy(Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
			    requestFactory.setProxy(proxy);
			    restTemplate.setRequestFactory(requestFactory);
		}
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		ResponseEntity<String> response = restTemplate.exchange(userDetailsURL, HttpMethod.POST, entity,String.class);
		if(response.getStatusCodeValue() == 200){
			  Map loginResponse = new  Commons().getGsonData(response.getBody());
			  Map responseData = (Map)((Map)loginResponse.get("response")).get("responseData");
			  List<Map<String,String>> transactions =(List<Map<String,String>>)responseData.get("Transactions");
				if(transactions!=null && !transactions.isEmpty()){
					if(AdcDesignationDetailsServiceImpl.designationMap.containsKey(transactions.get(0).get("mnyldesignation").toUpperCase())){
				        result=true;
				        request.getSession().setAttribute("username",transactions.get(0).get("mnyldisplayname").toUpperCase() );
					}else{
						log.error("Error While getting User Details through SOA API");
					}
				}else{
					log.error("Error While getting User Details through SOA API");
				}
	        }else{
	        	log.error("Error While getting User Details through SOA API");
	        }
		return result;
	}
	
	


}
