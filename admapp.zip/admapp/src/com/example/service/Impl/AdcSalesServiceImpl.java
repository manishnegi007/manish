package com.example.service.Impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.domain.AdcSales;
import com.example.repository.AdcSalesRepository;
import com.example.service.AdcSalesService;

@Service
public class AdcSalesServiceImpl implements AdcSalesService{
	
	Logger log =Logger.getLogger(AdcSalesServiceImpl.class);
	
	@Autowired
	AdcSalesRepository salesRepository;
	
	@Override
	public AdcSales createOrUpdate(AdcSales adcSales) {
	    log.info("Create Or Update Service called"+adcSales);
	    adcSales.setCreatedDateTime(new Date());
	    log.info(adcSales);
		adcSales = salesRepository.saveAndFlush(adcSales);
		log.info("created" +adcSales);
		return adcSales;
	}

	@Override
	public List<AdcSales> findAll() {
		// TODO Auto-generated method stub
		return salesRepository.findAll();
	}

	@Override
	public List<AdcSales> findAllBySsoIdAndSalesType(String ssoId,String salesType) {
		// TODO Auto-generated method stub
		List<AdcSales>  adcSalesList= new ArrayList<>();
	 	adcSalesList = salesRepository.findBySsoIdAndSalesTypeOrderByIdDesc(ssoId,salesType);
	 	return adcSalesList;
	 
	}

}
