package com.example.service.Impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.domain.AdcRecruitment;
import com.example.repository.AdcRecruitmentRepository;
import com.example.service.AdcRecruitmentService;

@Service
public class AdcRecruitmentServiceImpl implements AdcRecruitmentService {
   
	@Autowired
	AdcRecruitmentRepository recruitmentRepository;
	
	@Override
	public AdcRecruitment createOrUpdate(AdcRecruitment adcRecruitment) {
		adcRecruitment.setCreatedDateTime(new Date());
		return recruitmentRepository.saveAndFlush(adcRecruitment);
	}

	@Override
	public List<AdcRecruitment> findAll() {
		// TODO Auto-generated method stub
		return recruitmentRepository.findAll();
	}
	
	@Override
	public List<AdcRecruitment> findBySsoIdAndRecruitmentType(String ssoId, String recruitmentType) {
		// TODO Auto-generated method stub
		List<AdcRecruitment> adcRecruitmentList=new ArrayList<>();
		adcRecruitmentList = recruitmentRepository.findBySsoIdAndRecruitmentTypeOrderByIdDesc(ssoId, recruitmentType);
		return adcRecruitmentList;
	}

	
}
