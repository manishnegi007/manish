package com.example.service.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.domain.AdcDesignationDetails;
import com.example.repository.AdcDesignationDetailsRepository;
import com.example.service.AdcDesignationDetailsService;

@Service
public class AdcDesignationDetailsServiceImpl implements AdcDesignationDetailsService{
	
	public static Map<String,String> designationMap=new HashMap<>();

	@Autowired
	AdcDesignationDetailsRepository designationDetailsRepository;
	
	@Override
	public String populateDesignationMap(){
		List<AdcDesignationDetails> list= designationDetailsRepository.findAll();
		if(list.isEmpty() || list == null){
			return "error";
		}
		list.parallelStream().forEach(des->{
			designationMap.put(des.getDesigantionName(),"TRUE");
		});
		return "OK";	
	}
	
	@Override
	public List<AdcDesignationDetails> addAll() {
		// TODO Auto-generated method stub
		List<AdcDesignationDetails> list = new ArrayList<AdcDesignationDetails>();
		AdcDesignationDetails adcDesignationDetails1 = new AdcDesignationDetails("AGENCY DEVELOPMENT MANAGER","Agency Development Manager");
		AdcDesignationDetails adcDesignationDetails2 = new AdcDesignationDetails("ARM-ML","ARM-ML");
		AdcDesignationDetails adcDesignationDetails3 = new AdcDesignationDetails("ASSOCIATE AGENCY DEVELOPMENT MANAGER","Associate Partner-Sales");
		AdcDesignationDetails adcDesignationDetails4 = new AdcDesignationDetails("ASSOCIATE REGIONAL MANAGER","Associate Regional Manager");
		AdcDesignationDetails adcDesignationDetails5 = new AdcDesignationDetails("MANAGING PARTNER","Managing Partner");
		AdcDesignationDetails adcDesignationDetails6 = new AdcDesignationDetails("PARTNER- OH","Partner- OH");
		AdcDesignationDetails adcDesignationDetails7 = new AdcDesignationDetails("PARTNER-AGENCY SALES","Partner-Agency Sales");
		AdcDesignationDetails adcDesignationDetails8 = new AdcDesignationDetails("SENIOR MANAGING PARTNER","Senior Partner-OH");
		AdcDesignationDetails adcDesignationDetails9 = new AdcDesignationDetails("SR. AGENCY DEVELOPMENT MANAGER","Sr. Agency Development Manager");
		AdcDesignationDetails adcDesignationDetails10 = new AdcDesignationDetails("SR. ASSOCIATE PARTNER-AGENCY MANAGEMENT","Sr. Associate Partner-Agency Management");
		AdcDesignationDetails adcDesignationDetails11 = new AdcDesignationDetails("SR. PARTNER - SALES","Sr. Partner - Sales");
		AdcDesignationDetails adcDesignationDetails12 = new AdcDesignationDetails("SR.ASSOCIATE PARTNER-AGENCY SALES","Sr.Associate Partner-Agency Sales");
		AdcDesignationDetails adcDesignationDetails13 = new AdcDesignationDetails("ASSOCIATE PARTNER-SALES","Associate Partner-Sales");
		AdcDesignationDetails adcDesignationDetails14 = new AdcDesignationDetails("SENIOR PARTNER-OH","Senior Partner-OH");
		AdcDesignationDetails adcDesignationDetails15 = new AdcDesignationDetails("BENCH","BENCH");
		AdcDesignationDetails adcDesignationDetails16 = new AdcDesignationDetails("AGENCY MANAGER","Agency Manager");
		AdcDesignationDetails adcDesignationDetails17 = new AdcDesignationDetails("SR.ASSOCIATE PARTNER-AGENCY SALES","	Sr.Associate Partner-Agency Sales");
		AdcDesignationDetails adcDesignationDetails18 = new AdcDesignationDetails("CHIEF AGENCY MANAGER","Chief Agency Manager");
		AdcDesignationDetails adcDesignationDetails19 = new AdcDesignationDetails("EXECUTIVE AGENCY MANAGER","Executive Agency Manager");
		AdcDesignationDetails adcDesignationDetails20 = new AdcDesignationDetails("MASTER AGENCY MANAGER","Master Agency Manager");
		AdcDesignationDetails adcDesignationDetails21 = new AdcDesignationDetails("SENIOR MANAGING PARTNER","Senior Managing Partner");
		AdcDesignationDetails adcDesignationDetails22 = new AdcDesignationDetails("SENIOR AGENCY MANAGER","Senior Agency manager");
		list.add(adcDesignationDetails14);	
		list.add(adcDesignationDetails13);
		list.add(adcDesignationDetails12);
		list.add(adcDesignationDetails11);
		list.add(adcDesignationDetails10);
		list.add(adcDesignationDetails9);
		list.add(adcDesignationDetails8);
		list.add(adcDesignationDetails7);
		list.add(adcDesignationDetails6);
		list.add(adcDesignationDetails5);
		list.add(adcDesignationDetails4);
		list.add(adcDesignationDetails3);
		list.add(adcDesignationDetails2);
		list.add(adcDesignationDetails1);
		list.add(adcDesignationDetails15);
		list.add(adcDesignationDetails16);
		list.add(adcDesignationDetails17);
		list.add(adcDesignationDetails18);
		list.add(adcDesignationDetails19);
		list.add(adcDesignationDetails20);
		list.add(adcDesignationDetails21);
		list.add(adcDesignationDetails22);
		return designationDetailsRepository.save(list);
	}

	@Override
	public List<AdcDesignationDetails> findAll() {
		// TODO Auto-generated method stub
		return designationDetailsRepository.findAll();
	}

}
