package com.example.service;

import javax.servlet.http.HttpServletRequest;

import com.example.dto.LoginDTO;

public interface LoginService {
 
	public Boolean login(LoginDTO loginDTO,HttpServletRequest request);

}
