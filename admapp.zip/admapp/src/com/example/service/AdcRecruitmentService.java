package com.example.service;

import java.util.List;

import com.example.domain.AdcRecruitment;

public interface AdcRecruitmentService {
 public AdcRecruitment createOrUpdate(AdcRecruitment adcRecruitment);
 
 public List<AdcRecruitment> findAll();
 public List<AdcRecruitment> findBySsoIdAndRecruitmentType(String ssoId,String recruitmentType);
 
}
