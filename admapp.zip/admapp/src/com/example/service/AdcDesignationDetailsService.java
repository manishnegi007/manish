package com.example.service;

import java.util.List;

import com.example.domain.AdcDesignationDetails;

public interface AdcDesignationDetailsService {
 public List<AdcDesignationDetails> addAll();
 public List<AdcDesignationDetails> findAll();
String populateDesignationMap();
}
