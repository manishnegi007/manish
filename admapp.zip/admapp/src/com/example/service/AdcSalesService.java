package com.example.service;

import java.util.List;

import com.example.domain.AdcSales;

public interface AdcSalesService {
 public AdcSales createOrUpdate(AdcSales adcSales);
 public List<AdcSales> findAll();
 public List<AdcSales> findAllBySsoIdAndSalesType(String ssoId,String salesType);
}
