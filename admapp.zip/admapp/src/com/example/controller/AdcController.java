package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.domain.AdcRecruitment;
import com.example.domain.AdcSales;
import com.example.dto.LoginDTO;
import com.example.service.AdcRecruitmentService;
import com.example.service.AdcSalesService;
import com.example.service.LoginService;

@Controller
public class AdcController {
    @Autowired
    LoginService loginService;
	
	@Autowired
    AdcSalesService adcSalesService;
	
	@Autowired
	AdcRecruitmentService adcRecruitmentService;
	
	Logger log =Logger.getLogger(AdcController.class);
	
    @RequestMapping("/")
	public String index(@ModelAttribute LoginDTO loginDTO, Model model) {
		return "index";
	}
    
    @RequestMapping(value="/login",method={RequestMethod.POST})
    public String loginDo(@ModelAttribute LoginDTO loginDTO, Model model,HttpServletRequest request){
    	log.info(loginDTO);
    	try{
	    	Boolean response =loginService.login(loginDTO,request);
	    	if(response){
		    	request.getSession().setAttribute("loginDTO", loginDTO);
		    	List<AdcSales> adcNewSalesList = adcSalesService.findAllBySsoIdAndSalesType(loginDTO.getUsername().trim().toUpperCase(),"NEW");
		    	List<AdcSales> adcFollowUpSalesList = adcSalesService.findAllBySsoIdAndSalesType(loginDTO.getUsername().trim().toUpperCase(),"FOLLOW-UP");
		    	List<AdcRecruitment> adcNewRecruitmentList = adcRecruitmentService.findBySsoIdAndRecruitmentType(loginDTO.getUsername().trim().toUpperCase(),"NEW");
		    	List<AdcRecruitment> adcFollowUpRecruitmentList = adcRecruitmentService.findBySsoIdAndRecruitmentType(loginDTO.getUsername().trim().toUpperCase(),"FOLLOW-UP");
		    	model.addAttribute("adcSalesList", adcNewSalesList);
		    	model.addAttribute("adcFollowUpSalesList", adcFollowUpSalesList);
		    	model.addAttribute("adcNewRecruitmentList", adcNewRecruitmentList);
		    	model.addAttribute("adcFollowUpRecruitmentList", adcFollowUpRecruitmentList);
		    	 return "dashboard";
	    	}
    	}catch (Exception e) {
			// TODO: handle exception
    		model.addAttribute("STATUS", "ERROR");
    		log.error(e);
    		return "index";
    	
		}
    	model.addAttribute("STATUS", "ERROR");
    	return "index";
    }
    @RequestMapping(value="/dashboard",method={RequestMethod.POST,RequestMethod.GET})
    public String dashboard(HttpServletRequest request,Model model){
      	LoginDTO loginDTO =(LoginDTO) request.getSession().getAttribute("loginDTO");
      	if(loginDTO != null){
	    	List<AdcSales> adcNewSalesList = adcSalesService.findAllBySsoIdAndSalesType(loginDTO.getUsername().trim().toUpperCase(),"NEW");
	    	List<AdcSales> adcFollowUpSalesList = adcSalesService.findAllBySsoIdAndSalesType(loginDTO.getUsername().trim().toUpperCase(),"FOLLOW-UP");
	    	List<AdcRecruitment> adcNewRecruitmentList = adcRecruitmentService.findBySsoIdAndRecruitmentType(loginDTO.getUsername().trim().toUpperCase(),"NEW");
	    	List<AdcRecruitment> adcFollowUpRecruitmentList = adcRecruitmentService.findBySsoIdAndRecruitmentType(loginDTO.getUsername().trim().toUpperCase(),"FOLLOW-UP");
	    	model.addAttribute("adcSalesList", adcNewSalesList);
	    	model.addAttribute("adcFollowUpSalesList", adcFollowUpSalesList);
	    	model.addAttribute("adcNewRecruitmentList", adcNewRecruitmentList);
	    	model.addAttribute("adcFollowUpRecruitmentList", adcFollowUpRecruitmentList);
	    	return "dashboard";
      	}
      	return "index";
    }
    
    @RequestMapping(value="/sales",method=RequestMethod.GET)
    public String sales(@ModelAttribute("salesDTO") AdcSales salesDTO,BindingResult bindingResult,Model model,HttpServletRequest request){
    	List<String> customerTypes=new ArrayList<>();
    	customerTypes.add("Individual");
    	customerTypes.add("Assisted");
    	model.addAttribute("customerTypes", customerTypes);
    	model.addAttribute("salesDTO",new AdcSales());
    	return "sales";
    }
    
    @RequestMapping(value="/create-sales",method=RequestMethod.POST)
    public String createSales(@ModelAttribute("salesDTO") AdcSales salesDTO,BindingResult bindingResult,Model model,HttpServletRequest request){
    	LoginDTO loginDTO =(LoginDTO) request.getSession().getAttribute("loginDTO");
    	if(loginDTO != null){
	    	log.info("Creating new Sales"+salesDTO);
	    	try{
	    		log.info("New Sales Created");
	    		salesDTO.setSsoId(loginDTO.getUsername().trim().toUpperCase());
	    		salesDTO.setSalesType("NEW");
	    		salesDTO.setUsername(request.getSession().getAttribute("username").toString());
	    		salesDTO = adcSalesService.createOrUpdate(salesDTO);
	    		model.addAttribute("STATUS", "SUCCESS");
	    		model.addAttribute("salesDTO", new AdcSales());
	    	}catch(Exception e){
	    		log.error(e);
	    		model.addAttribute("salesDTO", new AdcSales());
	    		model.addAttribute("STATUS", "ERROR");
	    	}
	      	return "sales";
    	}
	    	return "index";
    }
    
    @RequestMapping(value="/follow-up-sales",method=RequestMethod.POST)
    public String followUpSales(@ModelAttribute("salesDTO") AdcSales salesDTO,BindingResult bindingResult,Model model,HttpServletRequest request){
    	log.info("Creating follow up sales"+salesDTO);
    	LoginDTO loginDTO = (LoginDTO) request.getSession().getAttribute("loginDTO");
    	if(loginDTO != null){
	    	try{
	    		salesDTO.setSsoId(loginDTO.getUsername().trim().toUpperCase());
	    		salesDTO.setSalesType("FOLLOW-UP");
	    		salesDTO.setUsername(request.getSession().getAttribute("username").toString());
	    		salesDTO = adcSalesService.createOrUpdate(salesDTO);
	    		model.addAttribute("STATUS","SUCCESS");
	    		model.addAttribute("salesDTO", new AdcSales());
	    	}catch(Exception e){
	    		log.error(e);
	    		model.addAttribute("salesDTO", new AdcSales());
	    		model.addAttribute("STATUS","ERROR");
	    	}
	    	return "sales";
    	}
    	return "index";
    }
    @RequestMapping(value="/recruitment",method=RequestMethod.GET)
    public String recruitment(@ModelAttribute("recruitmentDTO") AdcRecruitment adcRecruitment,BindingResult bindingResult,Model model,HttpServletRequest request){
    	model.addAttribute("recruitmentDTO", new AdcRecruitment());
    	return "recruitment";
    }
    
    @RequestMapping(value="/create-recruitment",method=RequestMethod.POST)
    public String createNewRecruitment(@ModelAttribute("recruitmentDTO") AdcRecruitment adcRecruitment,BindingResult bindingResult,Model model,HttpServletRequest request){
    	log.info("Creating new Recruitment"+adcRecruitment);
    	LoginDTO loginDTO = (LoginDTO) request.getSession().getAttribute("loginDTO");
    	if(loginDTO != null){
    		try{
    			adcRecruitment.setSsoId(loginDTO.getUsername().trim().toUpperCase());
    			adcRecruitment.setRecruitmentType("NEW");
    			adcRecruitment.setUsername(request.getSession().getAttribute("username").toString());
    			adcRecruitment = adcRecruitmentService.createOrUpdate(adcRecruitment);
    			model.addAttribute("recruitmentDTO", new AdcRecruitment());
    			model.addAttribute("STATUS","SUCCESS");
    		}catch (Exception e) {
    			log.error(e);
    			model.addAttribute("recruitmentDTO", new AdcRecruitment());
    			model.addAttribute("STATUS", "ERROR");
			}
    		return "recruitment";
    	}
    	return "index";
    }
    @RequestMapping(value="/follow-up-recruitment",method=RequestMethod.POST)
    public String createFollowUpRecruitment(@ModelAttribute("recruitmentDTO") AdcRecruitment adcRecruitment,BindingResult bindingResult,Model model,HttpServletRequest request){
    	log.info("Creating new Recruitment"+adcRecruitment);
    	LoginDTO loginDTO = (LoginDTO) request.getSession().getAttribute("loginDTO");
    	if(loginDTO != null){
    		try{
    			adcRecruitment.setSsoId(loginDTO.getUsername().trim().toUpperCase());
    			adcRecruitment.setRecruitmentType("FOLLOW-UP");
    			adcRecruitment.setUsername(request.getSession().getAttribute("username").toString());
    			adcRecruitment = adcRecruitmentService.createOrUpdate(adcRecruitment);
    			model.addAttribute("recruitmentDTO", new AdcRecruitment());
    			model.addAttribute("STATUS","SUCCESS");
    		}catch (Exception e) {
    			log.error(e);
    			model.addAttribute("recruitmentDTO", new AdcRecruitment());
    			model.addAttribute("STATUS", "ERROR");
			}
    		return "recruitment";
    	}
    	return "index";
    }
}
