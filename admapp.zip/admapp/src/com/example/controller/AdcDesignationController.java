package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.AdcDesignationDetails;
import com.example.service.AdcDesignationDetailsService;

@RestController
@RequestMapping("/designation")
public class AdcDesignationController {

	@Autowired
	AdcDesignationDetailsService designationService;
	
	@RequestMapping(value="/add-all",method={RequestMethod.POST,RequestMethod.GET})
	public List<AdcDesignationDetails> addAll(){
		return designationService.addAll();
	}
	
	@RequestMapping(value="/populate-designation-map",method=RequestMethod.GET)
	public String populateDesinationMap(){
		return designationService.populateDesignationMap();
	}
}
