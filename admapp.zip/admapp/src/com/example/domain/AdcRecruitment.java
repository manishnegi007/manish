package com.example.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ADC_RECRUITMENT")
public class AdcRecruitment {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	private String prospectName;
	private String prospectMobile;
	private String leadSource;
	
	private String ssoId;
	//New or Follow-Up
	private String recruitmentType;
	
	private String username;
	 
	private Date createdDateTime;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getProspectName() {
		return prospectName;
	}
	public void setProspectName(String prospectName) {
		this.prospectName = prospectName;
	}
	public String getProspectMobile() {
		return prospectMobile;
	}
	public void setProspectMobile(String prospectMobile) {
		this.prospectMobile = prospectMobile;
	}
	public String getLeadSource() {
		return leadSource;
	}
	
	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}
	
	public String getSsoId() {
		return ssoId;
	}
	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}
	public String getRecruitmentType() {
		return recruitmentType;
	}
	public void setRecruitmentType(String recruitmentType) {
		this.recruitmentType = recruitmentType;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	
	public Date getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	@Override
	public String toString() {
		return "AdcRecruitment [id=" + id + ", prospectName=" + prospectName + ", prospectMobile=" + prospectMobile
				+ ", leadSource=" + leadSource + ", ssoId=" + ssoId + ", recruitmentType=" + recruitmentType
				+ ", username=" + username + ", createdDateTime=" + createdDateTime + "]";
	}
	
	
	
}
