package com.example.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ADC_DESIGNATION_DETAILS")
public class AdcDesignationDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	private String desigantionName;
	private String designationCode;
	private String designationDescription;
	public AdcDesignationDetails(){}
	public AdcDesignationDetails(String desigantionName, String designationDescription) {
		this.desigantionName = desigantionName;
		this.designationDescription = designationDescription;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDesigantionName() {
		return desigantionName;
	}
	public void setDesigantionName(String desigantionName) {
		this.desigantionName = desigantionName;
	}
	public String getDesignationCode() {
		return designationCode;
	}
	public void setDesignationCode(String designationCode) {
		this.designationCode = designationCode;
	}
	public String getDesignationDescription() {
		return designationDescription;
	}
	public void setDesignationDescription(String designationDescription) {
		this.designationDescription = designationDescription;
	}
	@Override
	public String toString() {
		return "AdcDesignationDetails [id=" + id + ", desigantionName=" + desigantionName + ", designationCode="
				+ designationCode + ", designationDescription=" + designationDescription + "]";
	}
	
}
