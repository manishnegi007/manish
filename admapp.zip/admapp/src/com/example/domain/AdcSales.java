package com.example.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ADC_SALES")
public class AdcSales {

 @Id
 @GeneratedValue(strategy=GenerationType.AUTO)
 private Long id;
 
 private String customerType;
 private String customerName;
 private String customerMobile;
 private String customerNeed;
 private String ssoId;
 //New or Follow-up
 private String salesType;
 private String username;
 private Date createdDateTime;
 
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getCustomerType() {
	return customerType;
}
public void setCustomerType(String customerType) {
	this.customerType = customerType;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getCustomerMobile() {
	return customerMobile;
}
public void setCustomerMobile(String customerMobile) {
	this.customerMobile = customerMobile;
}
public String getCustomerNeed() {
	return customerNeed;
}
public void setCustomerNeed(String customerNeed) {
	this.customerNeed = customerNeed;
}

public String getSsoId() {
	return ssoId;
}
public void setSsoId(String ssoId) {
	this.ssoId = ssoId;
}

public String getSalesType() {
	return salesType;
}
public void setSalesType(String salesType) {
	this.salesType = salesType;
}

public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}


public Date getCreatedDateTime() {
	return createdDateTime;
}
public void setCreatedDateTime(Date createdDateTime) {
	this.createdDateTime = createdDateTime;
}
@Override
public String toString() {
	return "AdcSales [id=" + id + ", customerType=" + customerType + ", customerName=" + customerName
			+ ", customerMobile=" + customerMobile + ", customerNeed=" + customerNeed + ", ssoId=" + ssoId
			+ ", salesType=" + salesType + ", username=" + username + ", createdDateTime=" + createdDateTime + "]";
}
 
 
}
