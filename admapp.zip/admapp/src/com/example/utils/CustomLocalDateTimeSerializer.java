package com.example.utils;

import java.io.IOException;
import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

public class CustomLocalDateTimeSerializer extends StdSerializer<LocalDateTime>{

	private static final long serialVersionUID = 1L;
	public CustomLocalDateTimeSerializer() {
        this(null);
    }
  
    public CustomLocalDateTimeSerializer(Class<LocalDateTime> t) {
        super(t);
    }
	@Override
	public void serialize(LocalDateTime localDateTime, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
		// TODO Auto-generated method stub
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		jsonGenerator.writeString(formatter.format(localDateTime));
	}

}
