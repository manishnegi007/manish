package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.domain.AdcDesignationDetails;

public interface AdcDesignationDetailsRepository extends JpaRepository<AdcDesignationDetails, Long>{
 
}
